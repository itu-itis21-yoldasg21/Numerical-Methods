#Gülce Su Yoldaş 820210331

def rationaln_to_binaryn(num):
    integer = int(num)
    fractional = num- integer

    binary = ""
    while fractional> 0:
       
        fractional *= 2

       
        if fractional >= 1:
            binary += "1"
            fractional -= 1
        
        else:
            binary += "0"

    
   
    return binary

def integern_to_binaryn(num):
    num = int(num)


    binary = ""
    while num != 0:
        remainder = num % 2

        if remainder == 1:
            binary += "1"
        else:
            binary += "0"
       

    return binary


print(rationaln_to_binaryn(0.58) + "." + rationaln_to_binaryn(0.231) ) #output is 10010100011110101110000101000111101011100001010001111.0011101100100010110100001110010101100000010000011000101



