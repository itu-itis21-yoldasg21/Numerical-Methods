
# Gülce Su Yoldaş 820210331

import numpy as np
import matplotlib.pyplot as plt

def div_dif(x, y):
    n = len(x)
    co = np.zeros((n, n))
    co[:, 0] = y
    
    for j in range(1, n):
        for i in range(n - j):
            co[i][j] = (co[i + 1][j - 1] - co[i][j - 1]) / (x[i + j] - x[i])
    
    return co[0]



x = np.array([0, 1, 2, 4, 6])
y = np.array([1, 9, 23, 93, 259])
coefficients = div_dif(x, y)


x_range = np.linspace(np.min(x), np.max(x), 100)
y_range = np.zeros_like(x_range)

for i in range(len(x)):
    term = coefficients[i]
    for j in range(i):
        term *= (x_range - x[j])
    y_range += term

plt.plot(x, y, 'ro', label='Data Points')
plt.plot(x_range, y_range, label='Interpolate Curve')
plt.xlabel('x')
plt.ylabel('f(x)')
plt.title('Divided Difference Interpolation')
plt.legend()
plt.grid(True)
plt.show()
