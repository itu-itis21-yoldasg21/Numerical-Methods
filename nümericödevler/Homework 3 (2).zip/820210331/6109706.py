
#Gülce Su Yoldaş 820210331

import numpy as np
import matplotlib.pyplot as plt

def lagrange_interp(x, y):
    n = len(x)
    polynomial = np.poly1d(0.0)

    for j in range(n):
        p = np.poly1d(y[j])
        for k in range(n):
            if k != j:
                p *= np.poly1d([1.0 / (x[j] - x[k]), -x[k] / (x[j] - x[k])])
        polynomial += p

    return polynomial

x = np.array([-1.2, 0.3, 1.1])
y = np.array([-5.76, -5.61, -3.69])


interpolate_polynomial = lagrange_interp(x, y)
x_range = np.linspace(min(x) - 1, max(x) + 1, 100)
y_range = interpolate_polynomial(x_range)


plt.plot(x, y, 'ro', label=' Data points')
plt.plot(x_range, y_range, label='Interpolate polynomial')
plt.xlabel('x')
plt.ylabel('f(x)')
plt.title('Lagrange Interpolation')
plt.legend()
plt.grid(True)
plt.show()